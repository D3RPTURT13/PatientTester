
public class Patient {
	private String name;
	private int age;
	public double dosage;
	public double height; 
	public String heightUnits; 
	public double weight;
	public String weightUnits;
public Patient(String Name, int age) {
	this.name = Name;
	this.age = age;
}
public String getname() {
	return name;
}

public void setname(String name) {
	this.name = name;
}
public int getage() {
	return age;
}

public void setage(int age) {
	this.age = age;
}
public double dosage() {
	dosage = 600.0;
	return dosage;
}
public double bmi(double heightInMeters, double weightInKilograms) {
	double Calculation = weightInKilograms / heightInMeters;
	return Calculation;
}
public double bmi(double height, String heightUnits, double weight, String weightUnits) {
	height = height * .0254;
	weight = weight * .453592;
	double Calculation = weight / height;
	heightUnits = "in";
	weightUnits = "cm";
	return Calculation;
}
}
