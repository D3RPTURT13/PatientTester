
public class ChildPatient extends Patient {
	String parentName;
	public ChildPatient(String name, int age, String parentName) {
super(name, age);
this.parentName = parentName;
	}
	public String getparentName() {
		return parentName;
	}

	public void setparentName(String parentName) {
		this.parentName = parentName;
	}
	public double dosage() {
		dosage = 300.0;
		return dosage;
	}
	public double bmi(double heightInMeters, double weightInKilograms) {
		double Calculation = weightInKilograms / heightInMeters;
		return Calculation;
	}
	public double bmi(double height, String heightUnits, double weight, String weightUnits) {
		height = height * .0254;
		weight = weight * .453592;
		double Calculation = weight / height;
		heightUnits = "in";
		weightUnits = "cm";
		return Calculation;
	}
}
